package com.jingxi.officetest.network;

public class NetworkConstant {

	/**
	 * OSS -> JXPadMainTain
	 */
	public static final String BASE_URL = "http://smartlife-test.oss-cn-shanghai.aliyuncs.com/JXPadMainTain/main";
	
}
