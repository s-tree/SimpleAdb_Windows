package com.jingxi.officetest.network;

public class ScriptBean {
	public static final String NAME_NAME = "name";
	public static final String NAME_SCRIPT = "script";
	
	public String name;
	public String url;
}
